-  **登陆节点3311后台**

cdn节点的3311管理后台是登陆kangle管理的，cdn后台添加的站点和配置都是同步到节点程序上来运行的，因为节点初始安装密码是随机生成的，所以登陆需要修改密码
注：cdn的所有操作都可在cdn后台操作完成

登陆cdn的3311后台如下步骤操作：
1. 点击节点列表中节点ID号

![](http://54.151.143.251:4999/server/index.php?s=/api/attachment/visitFile/sign/a19b891dc0674fe6b5955840b3ef28a2)

2. 先选择开启kangle访问

![](http://54.151.143.251:4999/server/index.php?s=/api/attachment/visitFile/sign/b33f6e62bbd7114ab2c6984e09f43e71)

然后在浏览器输入节点登陆地址：http://ip:3311

- **备注**：无