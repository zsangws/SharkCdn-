-  **角色设置**

可以新建角色，设置角色所属的权限

![](http://54.151.143.251:4999/server/index.php?s=/api/attachment/visitFile/sign/fe52a2ba6f8088f359f100b8d3d48508)

- **备注**：无