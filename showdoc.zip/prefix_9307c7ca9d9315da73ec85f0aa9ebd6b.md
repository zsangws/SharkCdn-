-  **站点开启http2**

HTTP/2 （原名HTTP/2.0）即超文本传输协议 2.0，是下一代HTTP协议。在开放互联网上HTTP 2.0将只用于https:// 网址，而 http:// 网址将继续使用HTTP/1，目的是在开放互联网上增加使用加密技术，以提供强有力的保护去遏制主动攻击 IETF会让所有互联网通路默认选择的方式来引入加密，互联网专家们将新一代加密协议称为“HTTP 2.0”。

cdnbest如何开启http2

1.如下图先添加好https证书，然后开启http2，点立即提交

![](http://54.151.143.251:4999/server/index.php?s=/api/attachment/visitFile/sign/0305eaf3531fc26ca851b30e534b9903)

2.检查http2是否开启成功

本例是用firefox浏览器查看，按F12,如下图查看版本是否显示了http2

![](http://54.151.143.251:4999/server/index.php?s=/api/attachment/visitFile/sign/83fa431a1a236910403c84ad1e74700f)

- **备注**：无