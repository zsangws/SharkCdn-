-  **添加节点**

1.点击CDN管理---节点列表---新增节点 会弹出节点的安装程序

![](http://54.151.143.251:4999/server/index.php?s=/api/attachment/visitFile/sign/98eaf86a5d783c35b87255bbb385e1fd)

2.linux服务器，直接复制下图脚本命令运行。windows服务器，下载对应版本到服务器上运行安装。

![](http://54.151.143.251:4999/server/index.php?s=/api/attachment/visitFile/sign/209580b8c2cc6bc79addf2be5aa30e16)

- **备注**：安装成功后,节点会出现在待初始化列表,点击初始化
4.6.0版初始化是默认不显示，有新节点需要初始化时会自动显示
区域：选择要初始化节点到哪个区域
名字：设置节点的名字，只能用英文和数字。
节点类型：选择默认的边缘节点就行了。 中间节点是多层CDN功能(需vip4以上套餐支持)。
备注：可留空

![](http://54.151.143.251:4999/server/index.php?s=/api/attachment/visitFile/sign/203043cc9a8ccf3bd0e80dda089a0001)

4.初始化成功后，节点会显示在对应的区域中。

- **备注**：无