-  **数据统计**

cdn内拥有的资源的统计。
![](http://54.151.143.251:4999/server/index.php?s=/api/attachment/visitFile/sign/eba051c0be7cffebeacf0eb691b9befb)
