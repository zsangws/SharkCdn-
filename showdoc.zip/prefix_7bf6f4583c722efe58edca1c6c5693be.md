-  **日志**

同步日志记录了该区域下所有站点的操作记录

在区域列表点击日志

![](http://54.151.143.251:4999/server/index.php?s=/api/attachment/visitFile/sign/07a3f2f97c8247908892de09744f1933)

![](http://54.151.143.251:4999/server/index.php?s=/api/attachment/visitFile/sign/aca0693dd89f2b813f13b25e683f84ae)
- **备注**：无