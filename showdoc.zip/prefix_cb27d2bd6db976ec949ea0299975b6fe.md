-  **基本信息**

包含用户ID，用户名称，注册时间，邮箱，手机号码，账户信息，账户余额，VIP套餐，VIP过期时间，授权码，系统信息，系统版本，API文档的用户基本信息。

![](http://54.151.143.251:4999/server/index.php?s=/api/attachment/visitFile/sign/2b72a078124c799fd72368da73bcea89)

