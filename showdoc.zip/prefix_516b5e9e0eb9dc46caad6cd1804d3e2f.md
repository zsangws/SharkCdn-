-  **端口**

区域里面设置的端口是指允许站点可以设置的端口，如果区域没有开放这个端口，那么站点设置里面就无法设置该端口

1.先去区域里面开放端口，如下图

![](http://54.151.143.251:4999/server/index.php?s=/api/attachment/visitFile/sign/c66157331971dc02fefb1bbadf0c29ac)

2.站点设置里面添加开放的端口，如下图

![](http://54.151.143.251:4999/server/index.php?s=/api/attachment/visitFile/sign/3e4f38fe206d826af06110077fcfea93)

- **备注**：区域设置的端口，不允许在站点里面的四层端口设置该端口，会提示该端口已占用