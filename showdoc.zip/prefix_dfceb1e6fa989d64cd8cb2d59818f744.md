-  **错误url设置**

![](http://54.151.143.251:4999/server/index.php?s=/api/attachment/visitFile/sign/8c0122c86e0c848cd2e9b3574e4f0604)

- **备注**：如上图，可以点击建议设置，显示http://ip:82/system/error ip是你主控的ip
也可以输入域名，https格式为：https://域名:4430/system/error http格式为：http://域名:82/system/error 域名是你自己的域名，要解析到cdn主控ip