-  **域名开启HSTS**

HSTS介绍：

国际互联网工程组织IETE正在推行一种新的Web安全协议HTTP Strict Transport Security（HSTS）

采用HSTS协议的网站将保证浏览器始终连接到该网站的HTTPS加密版本，不需要用户手动在URL地址栏中输入加密地址。

该协议将帮助网站采用全局加密，用户看到的就是该网站的安全版本。

HSTS的作用是强制客户端（如浏览器）使用HTTPS与服务器创建连接。服务器开启HSTS的方法是，当客户端通过HTTPS发出请求时，在服务器返回的超文本传输协议响应头中包含Strict-Transport-Security字段。非加密传输时设置的HSTS字段无效。

比如，https://xxx 的响应头含有Strict-Transport-Security: max-age=31536000; includeSubDomains。这意味着两点：

在接下来的一年（即31536000秒）中，浏览器只要向xxx或其子域名发送HTTP请求时，必须采用HTTPS来发起连接。比如，用户点击超链接或在地址栏输入 http://xxx/ ，浏览器应当自动将 http 转写成 https，然后直接向 https://xxx/ 发送请求。

在接下来的一年中，如果 xxx 服务器发送的TLS证书无效，用户不能忽略浏览器警告继续访问网站

在cdnbest站点里面添加一条域名记录，如图


**点击上图绿色笔图标增加ssl证书，如下图所示ssl证书增加成功，**可参考自动获取ssl证书教程

![](http://54.151.143.251:4999/server/index.php?s=/api/attachment/visitFile/sign/9450c24d8ed36a4de3d400155e54d7af)

最后开启HSTS功能，也是点击绿色笔图标进入，如下图

![](http://54.151.143.251:4999/server/index.php?s=/api/attachment/visitFile/sign/191b3ca297553836caffaa9bc1e9a56d)

开启HSTS后，检查是否成功，我们访问域名，按F12查看，响应头出现Strict-Transport-Security：max-age=2592000（表示HSTS有效期，单位秒），则表示设置成功。
如下图

![](http://54.151.143.251:4999/server/index.php?s=/api/attachment/visitFile/sign/c1390d86b1f2c70e9b2315d9e1eb4811)

HSTS有效期可以自定义
进入站点设置，选择https设置，HSTS有效期，单位为月，点击提交，如下图

![](http://54.151.143.251:4999/server/index.php?s=/api/attachment/visitFile/sign/87bbccebd01d3dfa66c7e134e4673984)

设置自定义有效期后，可以访问域名，按F12查看是否自定义成功，如下图

![](http://54.151.143.251:4999/server/index.php?s=/api/attachment/visitFile/sign/612518f13434c5d3d69bc23e44a36ad0)

- **备注**：无